import{a as r}from"../chunks/C-a7_x20.js";import{x as t}from"../chunks/CR8Eiw6R.js";export{t as load_css,r as start};
