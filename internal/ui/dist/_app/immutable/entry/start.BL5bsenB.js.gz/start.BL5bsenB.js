import{a as r}from"../chunks/BaDBcM77.js";import{x as t}from"../chunks/DF-P8710.js";export{t as load_css,r as start};
