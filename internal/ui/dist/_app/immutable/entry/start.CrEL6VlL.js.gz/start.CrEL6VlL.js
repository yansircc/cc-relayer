import{a as r}from"../chunks/B1v15mmW.js";import{x as t}from"../chunks/BHL02ULs.js";export{t as load_css,r as start};
