import{a as r}from"../chunks/CAmDXm65.js";import{x as t}from"../chunks/VDlt5e0a.js";export{t as load_css,r as start};
