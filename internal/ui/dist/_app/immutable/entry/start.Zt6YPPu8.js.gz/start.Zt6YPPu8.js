import{a as r}from"../chunks/Cku8jTbS.js";import{x as t}from"../chunks/B36JXrSm.js";export{t as load_css,r as start};
