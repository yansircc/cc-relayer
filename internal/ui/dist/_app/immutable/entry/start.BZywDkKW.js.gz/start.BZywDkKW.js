import{a as r}from"../chunks/DP1SWo-P.js";import{x as t}from"../chunks/DmuWyb2n.js";export{t as load_css,r as start};
