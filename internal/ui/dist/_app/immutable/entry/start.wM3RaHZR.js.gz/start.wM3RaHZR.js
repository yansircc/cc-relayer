import{a as r}from"../chunks/Ov88F790.js";import{x as t}from"../chunks/BaD-Jc5Z.js";export{t as load_css,r as start};
