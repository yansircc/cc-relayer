import{a as r}from"../chunks/BZPCr9dl.js";import{x as t}from"../chunks/NZDo04p-.js";export{t as load_css,r as start};
